var images = {
    0: {
        title: "#13 SB I-35 Upper Deck",
        path: "Images/Capitol 009.JPG",
        location: [-97.727314, 30.283061]
    },
    1: {
        title: "#18 Zilker Clubhouse",
        path: "Images/Capitol 070.JPG",
        location: [-97.779239, 30.270478]
    },
    2: {
        title: "#28 N Congress @ MLK Blvd",
        path: "Images/Capitol 104.JPG",
        location: [-97.737999, 30.280725]
    },
    3: {
        title: "#10 Pleasant Valley @ S Lakeshore",
        path: "Images/Lakeshore 009.JPG",
        location: [-97.717332, 30.243198],
    },
    4: {
        title: "#6 Congress @ 6th St",
        path: "Images/Lemon 006.JPG",
        location: [-97.742814, 30.268052]
    },
    5: {
        title: "#16 E 7th Street Bridge over Texas-New Orleans RR",
        path: "Images/MLK 021.JPG",
        location: [-97.707052, 30.258991]
    },
    6: {
        title: "#23 Robert Mueller Airport",
        path: "Images/Mueller 008.JPG",
        location: [-97.699774, 30.292478],
    },
    7: {
        title: "#22 38th St @ Red River",
        path: "Images/Noodle 016.JPG", 
        location: [-97.723506, 30.295442]
    },
    8: {
        title: "#27 LBJ Library",
        path: "Images/Noodle 025.JPG",
        location: [-97.727969, 30.283250]
    }
}